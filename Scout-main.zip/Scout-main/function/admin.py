from django.contrib import admin
from function.models import formsubmit

# Register your models here.
admin.site.register(formsubmit)